library(testthat)
library(betaSandwich)

test_check("betaSandwich")
