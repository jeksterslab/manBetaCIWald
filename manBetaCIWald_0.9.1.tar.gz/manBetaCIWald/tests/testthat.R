library(testthat)
library(manBetaCIWald)

test_check("manBetaCIWald")
